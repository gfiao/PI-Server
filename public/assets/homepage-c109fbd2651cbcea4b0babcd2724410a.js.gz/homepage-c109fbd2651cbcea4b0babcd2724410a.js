/**
 * Created by Rafael on 29/05/2014.
 */


$(document).ready(function () {
    var interval_ID = setInterval(function () {
        alert(window.CurrVideo.index);
    }, 2000);
});
